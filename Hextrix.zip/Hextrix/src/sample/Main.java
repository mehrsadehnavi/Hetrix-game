package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

public class Main extends Application {
    Polygon p = new Polygon();

    boolean gameOver = false;

    // starting i and j;
    int i = 0;
    int j = 7;

    int save = 0;

    int random = (int) (Math.random() * 7 + 1);

    double yOdd = 390, yEven = 400;

    @Override
    public void start(Stage stage) throws InterruptedException {
        Pane pane = new Pane();
        Scene scene = new Scene(pane, 460 * Math.sqrt(3) / 3, 420, Color.BLACK);

        double x, count = 0, y;
        int board[][] = new int[21][15];
        double limit[] = new double[15];
        for (int z = 0; z < 15; z++) {
            if (z % 2 == 0)
                limit[z] = yEven;
            else
                limit[z] = yOdd;
        }

        //drawing the board.
        for (x = 0; count <= 20; x += 20, i++) {
            Polygon p = new Polygon();
            Polygon p2 = new Polygon();
            p.getPoints().addAll(1 + 10 * Math.sqrt(3) / 3, x,
                    1 + 10 * Math.sqrt(3), x,
                    1 + 40 * Math.sqrt(3) / 3, x + 10,
                    1 + 10 * Math.sqrt(3), x + 20,
                    1 + 10 * Math.sqrt(3) / 3, x + 20,
                    1.0, x + 10);
            board[i][0] = 1;
            p2.getPoints().addAll(430 * Math.sqrt(3) / 3, x,
                    450 * Math.sqrt(3) / 3, x,
                    460 * Math.sqrt(3) / 3, x + 10,
                    450 * Math.sqrt(3) / 3, x + 20,
                    430 * Math.sqrt(3) / 3, x + 20,
                    420 * Math.sqrt(3) / 3, x + 10);
            board[i][14] = 1;
            count ++;
            pane.getChildren().add(p);
            pane.getChildren().add(p2);
            p.setFill(Color.FORESTGREEN);
            p2.setFill(Color.FORESTGREEN);
        }

        // odd.
        count = 0;
        i = 0;
        for (x = 30 * Math.sqrt(3) / 3; count <= 6; x += 20 * Math.sqrt(3), i++) {
            Polygon p = new Polygon();
            p.getPoints().addAll(x, 400.0,
                    x + 10 * Math.sqrt(3) / 3, 390.0,
                    x + 10 * Math.sqrt(3), 390.0,
                    x + 40 * Math.sqrt(3) / 3, 400.0,
                    x + 10 * Math.sqrt(3), 410.0,
                    x + 10 * Math.sqrt(3) / 3, 410.0);
            board[20][(2 * i + 1)] = 1;
            count ++;
            pane.getChildren().add(p);
            p.setFill(Color.FORESTGREEN);
        }

        // even.
        count = 0;
        i = 1;
        for (x = 0; count <= 6; x += 20 * Math.sqrt(3)) {
            Polygon p = new Polygon();
            p.getPoints().addAll(x, 410.0,
                    x + 10 * Math.sqrt(3) / 3, 400.0,
                    x + 10 * Math.sqrt(3), 400.0,
                    x + 40 * Math.sqrt(3) / 3, 410.0,
                    x + 10 * Math.sqrt(3), 420.0,
                    x + 10 * Math.sqrt(3) / 3, 420.0);
            board[20][(2 * i)] = 1;
            count ++;
            pane.getChildren().add(p);
            p.setFill(Color.FORESTGREEN);
        }

        // Shapes appearing randomly.
        FirstShape firstShape = new FirstShape();
        SecondShape secondShape = new SecondShape();
        ThirdShape thirdShape = new ThirdShape();
        ForthShape forthShape = new ForthShape();
        FifthShape fifthShape = new FifthShape();
        SixthShape sixthShape = new SixthShape();
        SeventhShape seventhShape = new SeventhShape();
        switch (random) {
            case 1:
                p = firstShape.draw();
                break;
            case 2:
                p = secondShape.draw();
                break;
            case 3:
                p = thirdShape.draw();
                break;
            case 4:
                p = forthShape.draw();
                break;
            case 5:
                p = fifthShape.draw();
                break;
            case 6:
                p = sixthShape.draw();
                break;
            case 7:
                p = seventhShape.draw();
                break;
        }

        pane.getChildren().add(p);
        Timeline timeline = new Timeline(new KeyFrame(new Duration(500),
                new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        switch (random) {
                            case 1:
                                if (p.getLayoutY() + 90 < limit[j]) {
                                    moveDown(p);
                                    i++;
                                } else {
                                    board[i][j] = 1;
                                    board[i + 1][j] = 1;
                                    board[i + 2][j] = 1;
                                    board[i + 3][j] = 1;
                                    limit[j] = p.getLayoutY() + 10;
                                    save = 1;
                                }
                                scene.setOnKeyPressed(e -> {
                                    if (e.getCode() == KeyCode.A) {
                                        if ((board[i][j - 1] == 0) && (board[i + 1][j - 1] == 0) && (board[i + 2][j - 1] == 0) && (board[i + 3][j - 1] == 0)) {
                                            if (j % 2 == 0) {
                                                moveLeftEven(p);
                                                j--;
                                            } else {
                                                moveLeftOdd(p);
                                                j--;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.D) {
                                        if ((board[i][j + 1] == 0) && (board[i + 1][j + 1] == 0) && (board[i + 2][j + 1] == 0) && (board[i + 3][j + 1] == 0)) {
                                            if (j % 2 == 0) {
                                                moveRightEven(p);
                                                j++;
                                            } else {
                                                moveRightOdd(p);
                                                j++;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.W) {
                                        p.getTransforms().add(new Rotate(60, firstShape.x + 10 * Math.sqrt(3) / 3, firstShape.y + 10));
                                    }
                                    else if (e.getCode() == KeyCode.S) {
                                        if (j % 2 == 1) {
                                            if (p.getLayoutY() + 90 < limit[j]) {
                                                moveFast(p);
                                                i++;
                                            }
                                        }
                                        else {
                                            if (p.getLayoutY() + 90 < limit[j]) {
                                                moveFast(p);
                                                i++;
                                            }
                                        }
                                    }
                                });
                                break;
                            case 2:
                                if (p.getLayoutY() + 70 < limit[j] && p.getLayoutY() + 80 < limit[j + 1]) {
                                    moveDown(p);
                                    i++;
                                } else {
                                    board[i][j] = 1;
                                    board[i + 1][j] = 1;
                                    board[i + 2][j] = 1;
                                    board[i + 2][j + 1] = 1;
                                    limit[j] = p.getLayoutY() + 10;
                                    limit[j + 1] = p.getLayoutY() + 60;
                                    save = 1;
                                }
                                scene.setOnKeyPressed(e -> {
                                    if (e.getCode() == KeyCode.A) {
                                        if ((board[i][j - 1] == 0) && (board[i + 1][j - 1] == 0) && (board[i + 2][j - 1] == 0) && (board[i + 3][j] == 0)) {
                                            if (j % 2 == 0) {
                                                moveLeftEven(p);
                                                j--;
                                            } else {
                                                moveLeftOdd(p);
                                                j--;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.D) {
                                        if ((board[i][j + 1] == 0) && (board[i + 1][j + 1] == 0) && (board[i + 2][j + 1] == 0) && (board[i + 3][j + 2] == 0)) {
                                            if (j % 2 == 0) {
                                                moveRightEven(p);
                                                j++;
                                            } else {
                                                moveRightOdd(p);
                                                j++;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.W) {
                                        p.getTransforms().add(new Rotate(60, secondShape.x + 10 * Math.sqrt(3) / 3, secondShape.y + 10));
                                    }
                                    else if (e.getCode() == KeyCode.S) {
                                        if (p.getLayoutY() + 70 < limit[j] && p.getLayoutY() + 80 < limit[j + 1]) {
                                            moveFast(p);
                                            i++;
                                        }
                                    }
                                });
                                break;
                            case 3:
                                if (p.getLayoutY() + 50 < limit[j] && p.getLayoutY() + 80 < limit[j - 1]) {
                                    moveDown(p);
                                    i++;
                                } else {
                                    board[i][j] = 1;
                                    board[i + 1][j] = 1;
                                    board[i + 2][j - 1] = 1;
                                    board[i + 3][j - 1] = 1;
                                    limit[j] = p.getLayoutY() + 10;
                                    limit[j - 1] = p.getLayoutY() + 40;
                                    save = 1;
                                }
                                scene.setOnKeyPressed(e -> {
                                    if (e.getCode() == KeyCode.A) {
                                        if ((board[i][j - 1] == 0) && (board[i + 1][j - 1] == 0) && (board[i + 2][j - 2] == 0) && (board[i + 3][j - 2] == 0)) {
                                            if (j % 2 == 0) {
                                                moveLeftEven(p);
                                                j--;
                                            } else {
                                                moveLeftOdd(p);
                                                j--;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.D) {
                                        if ((board[i][j + 1] == 0) && (board[i + 1][j + 1] == 0) && (board[i + 2][j] == 0) && (board[i + 3][j] == 0)) {
                                            if (j % 2 == 0) {
                                                moveRightEven(p);
                                                j++;
                                            } else {
                                                moveRightOdd(p);
                                                j++;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.W) {
                                        p.getTransforms().add(new Rotate(60, thirdShape.x + 10 * Math.sqrt(3) / 3, thirdShape.y + 10));
                                    }
                                    else if (e.getCode() == KeyCode.S) {
                                        if (p.getLayoutY() + 50 < limit[j] && p.getLayoutY() + 80 < limit[j - 1]) {
                                            moveFast(p);
                                            i++;
                                        }
                                    }
                                });
                                break;
                            case 4:
                                if (p.getLayoutY() + 50 < limit[j] && p.getLayoutY() + 40 < limit[j - 1] && p.getLayoutY() + 40 < limit[j + 1]) {
                                    moveDown(p);
                                    i++;
                                } else {
                                    board[i][j] = 1;
                                    board[i + 1][j] = 1;
                                    board[i + 1][j + 1] = 1;
                                    board[i + 1][j - 1] = 1;
                                    limit[j] = p.getLayoutY() + 10;
                                    limit[j + 1] = p.getLayoutY() + 20;
                                    limit[j - 1] = p.getLayoutY() + 20;
                                    save = 1;
                                }
                                scene.setOnKeyPressed(e -> {
                                    if (e.getCode() == KeyCode.A) {
                                        if ((board[i][j - 1] == 0) && (board[i + 1][j - 2] == 0)) {
                                            if (j % 2 == 0) {
                                                moveLeftEven(p);
                                                j--;
                                            } else {
                                                moveLeftOdd(p);
                                                j--;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.D) {
                                        if ((board[i][j + 1] == 0) && (board[i + 1][j + 2] == 0)) {
                                            if (j % 2 == 0) {
                                                moveRightEven(p);
                                                j++;
                                            } else {
                                                moveRightOdd(p);
                                                j++;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.W) {
                                        p.getTransforms().add(new Rotate(60, forthShape.x + 10 * Math.sqrt(3) / 3, forthShape.y + 10));
                                    }
                                    else if (e.getCode() == KeyCode.S) {
                                        if (p.getLayoutY() + 50 < limit[j] && p.getLayoutY() + 40 < limit[j - 1] && p.getLayoutY() + 40 < limit[j + 1]) {
                                            moveFast(p);
                                            i++;
                                        }
                                    }
                                });
                                break;
                            case 5:
                                if (p.getLayoutY() + 70 < limit[j] && p.getLayoutY() + 40 < limit[j + 1]) {
                                    moveDown(p);
                                    i++;
                                } else {
                                    board[i][j] = 1;
                                    board[i + 1][j + 1] = 1;
                                    board[i + 1][j] = 1;
                                    board[i + 2][j] = 1;
                                    limit[j] = p.getLayoutY() + 10;
                                    limit[j + 1] = p.getLayoutY() + 20;
                                    save = 1;
                                }
                                scene.setOnKeyPressed(e -> {
                                    if (e.getCode() == KeyCode.A) {
                                        if ((board[i][j - 1] == 0) && (board[i + 1][j - 1] == 0) && (board[i + 2][j - 1] == 0) && (board[i + 3][j - 1] == 0)) {
                                            if (j % 2 == 0) {
                                                moveLeftEven(p);
                                                j--;
                                            } else {
                                                moveLeftOdd(p);
                                                j--;
                                            }
                                        }
                                    } else if (e.getCode() == KeyCode.D) {
                                        if ((board[i][j + 1] == 0) && (board[i + 1][j + 1] == 0) && (board[i + 2][j + 1] == 0) && (board[i + 1][j + 2] == 0)) {
                                            if (j % 2 == 0) {
                                                moveRightEven(p);
                                                j++;
                                            } else {
                                                moveRightOdd(p);
                                                j++;
                                            }
                                        }
                                    } else if (e.getCode() == KeyCode.W) {
                                        p.getTransforms().add(new Rotate(60, fifthShape.x + 10 * Math.sqrt(3) / 3, fifthShape.y + 10));
                                    } else if (e.getCode() == KeyCode.S) {
                                        if (p.getLayoutY() + 70 < limit[j] && p.getLayoutY() + 40 < limit[j + 1]) {
                                            moveFast(p);
                                            i++;
                                        }
                                    }
                                });
                                break;
                            case 6:
                                if (p.getLayoutY() + 70 < limit[j] && p.getLayoutY() + 40 < limit[j - 1]) {
                                    moveDown(p);
                                    i++;
                                } else {
                                    board[i][j] = 1;
                                    board[i + 1][j - 1] = 1;
                                    board[i + 1][j] = 1;
                                    board[i + 2][j] = 1;
                                    limit[j] = p.getLayoutY() + 10;
                                    limit[j - 1] = p.getLayoutY() + 20;
                                    save = 1;
                                }
                                scene.setOnKeyPressed(e -> {
                                    if (e.getCode() == KeyCode.A) {
                                        if ((board[i][j - 1] == 0) && (board[i + 1][j - 1] == 0) && (board[i + 2][j - 1] == 0) && (board[i + 1][j - 2] == 0)) {
                                            if (j % 2 == 0) {
                                                moveLeftEven(p);
                                                j--;
                                            } else {
                                                moveLeftOdd(p);
                                                j--;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.D) {
                                        if ((board[i][j + 1] == 0) && (board[i + 1][j + 1] == 0) && (board[i + 2][j + 1] == 0) && (board[i + 3][j + 1] == 0)) {
                                            if (j % 2 == 0) {
                                                moveRightEven(p);
                                                j++;
                                            } else {
                                                moveRightOdd(p);
                                                j++;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.W) {
                                        p.getTransforms().add(new Rotate(60, firstShape.x + 10 * Math.sqrt(3) / 3, firstShape.y + 10));
                                    }
                                    else if (e.getCode() == KeyCode.S) {
                                        if (p.getLayoutY() + 70 < limit[j] && p.getLayoutY() + 40 < limit[j - 1]) {
                                            moveFast(p);
                                            i++;
                                        }
                                    }
                                });
                                break;
                            case 7:
                                if (p.getLayoutY() + 60 < limit[j - 1] && p.getLayoutY() + 50 < limit[j] && p.getLayoutY() + 60 < limit[j + 1]) {
                                    moveDown(p);
                                    i++;
                                } else {
                                    board[i][j] = 1;
                                    board[i + 1][j] = 1;
                                    board[i + 2][j - 1] = 1;
                                    board[i + 2][j + 1] = 1;
                                    limit[j - 1] = p.getLayoutY() + 40;
                                    limit[j] = p.getLayoutY() + 10;
                                    limit[j + 1] = p.getLayoutY() + 40;
                                    save = 1;
                                }
                                scene.setOnKeyPressed(e -> {
                                    if (e.getCode() == KeyCode.A) {
                                        if ((board[i][j - 1] == 0) && (board[i + 1][j - 2] == 0)) {
                                            if (j % 2 == 0) {
                                                moveLeftEven(p);
                                                j--;
                                            } else {
                                                moveLeftOdd(p);
                                                j--;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.D) {
                                        if ((board[i][j + 1] == 0) && (board[i + 1][j + 2] == 0)) {
                                            if (j % 2 == 0) {
                                                moveRightEven(p);
                                                j++;
                                            } else {
                                                moveRightOdd(p);
                                                j++;
                                            }
                                        }
                                    }
                                    else if (e.getCode() == KeyCode.W) {
                                        p.getTransforms().add(new Rotate(60, seventhShape.x + 10 * Math.sqrt(3) / 3, seventhShape.y + 10));
                                    }
                                    else if (e.getCode() == KeyCode.S) {
                                        if (p.getLayoutY() + 60 < limit[j - 1] && p.getLayoutY() + 50 < limit[j] && p.getLayoutY() + 60 < limit[j + 1]) {
                                            moveFast(p);
                                            i++;
                                        }
                                    }
                                });
                                break;
                        }
                    }
                }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        Timeline t = new Timeline(new KeyFrame(new Duration(800),
                new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        if (limit[7] <= 50) {
                            gameOver = true;
                            Rectangle rectangle = new Rectangle(0,0,420,420);
                            rectangle.setFill(Color.BLACK);
                            pane.getChildren().add(rectangle);
                            Text text = new Text(100, 210,"Game over");
                            text.setFill(Color.RED);
                            text.setFont(Font.font("Chiller", FontWeight.BOLD, FontPosture.REGULAR, 50));
                            text.setX(60);
                            text.setY(210);
                            pane.getChildren().add(text);
                        }
                        else if (save == 1 && gameOver == false) {
                            timeline.pause();
                            i = 0;
                            j = 7;
                            random = (int) (Math.random() * 7 + 1);
                            switch (random) {
                                case 1:
                                    p = firstShape.draw();
                                    break;
                                case 2:
                                    p = secondShape.draw();
                                    break;
                                case 3:
                                    p = thirdShape.draw();
                                    break;
                                case 4:
                                    p = forthShape.draw();
                                    break;
                                case 5:
                                    p = fifthShape.draw();
                                    break;
                                case 6:
                                    p = sixthShape.draw();
                                    break;
                                case 7:
                                    p = seventhShape.draw();
                                    break;
                            }
                            pane.getChildren().add(p);
                            moveDown(p);
                            save = 0;
                            timeline.play();
                        }
                    }
                }));
        t.setCycleCount(Timeline.INDEFINITE);
        t.play();

        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    public static void moveRightEven(Polygon p) {
        p.setLayoutX(p.getLayoutX() + 30 * Math.sqrt(3) / 3);
        p.setLayoutY(p.getLayoutY() - 10);
    }

    public static void moveRightOdd(Polygon p) {
        p.setLayoutX(p.getLayoutX() + 30 * Math.sqrt(3) / 3);
        p.setLayoutY(p.getLayoutY() + 10);
    }

    public static void moveLeftEven(Polygon p) {
        p.setLayoutX(p.getLayoutX() - 30 * Math.sqrt(3) / 3);
        p.setLayoutY(p.getLayoutY() - 10);
    }

    public static void moveLeftOdd(Polygon p) {
        p.setLayoutX(p.getLayoutX() - 30 * Math.sqrt(3) / 3);
        p.setLayoutY(p.getLayoutY() + 10);
    }

    public static void moveFast(Polygon p) {
        p.setLayoutY(p.getLayoutY() + 20);
    }

    public static void moveDown(Polygon p) {
        p.setLayoutY(p.getLayoutY() + 20);
    }

    public static void main(String[] args){
        launch(args);
    }
}