package sample;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

public class FirstShape extends Polygon {
    double x = 220 * Math.sqrt(3) / 3, y = 10;

    Polygon polygon = new Polygon();

    public Polygon getPolygon() {
        return polygon;
    }

    public void setPolygon(Polygon polygon) {
        this.polygon = polygon;
    }

    public FirstShape() {
    }

    public double getX () {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) { this.y = y * 10; }

    public void setX(double x) {
        this.x = x ;
    }

    public Polygon draw () {
        Polygon polygon = new Polygon();
        polygon.getPoints().addAll(
                x, y,
                x + 20 * Math.sqrt(3) / 3, y,
                x + 30 * Math.sqrt(3) / 3, y + 10,
                x + 20 * Math.sqrt(3) / 3, y + 20,
                x + 30 * Math.sqrt(3) / 3, y + 30,
                x + 20 * Math.sqrt(3) / 3, y + 40,
                x + 30 * Math.sqrt(3) / 3, y + 50,
                x + 20 * Math.sqrt(3) / 3, y + 60,
                x + 30 * Math.sqrt(3) / 3, y + 70,
                x + 20 * Math.sqrt(3) / 3, y + 80,
                x, y + 80,
                x - 10 * Math.sqrt(3) / 3, y + 70,
                x, y + 60,
                x - 10 * Math.sqrt(3) / 3, y + 50,
                x, y + 40,
                x - 10 * Math.sqrt(3) / 3, y + 30,
                x, y + 20,
                x - 10 * Math.sqrt(3) / 3, y + 10
        );
        polygon.setFill(Color.YELLOW);
        return polygon;
    }
}
