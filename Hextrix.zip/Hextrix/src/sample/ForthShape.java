package sample;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

public class ForthShape extends Polygon {
    double x = 210 * Math.sqrt(3) / 3, y = 20;

    public ForthShape() {
    }

    public double getX () {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) { this.y = y * 10; }

    public void setX(double x) {
        this.x = x ;
    }


    public Polygon draw() {
        Polygon polygon = new Polygon();
        polygon.getPoints().addAll(
                x, y,
                x + 10 * Math.sqrt(3) / 3, y - 10,
                x + 30 * Math.sqrt(3) / 3, y - 10,
                x + 40 * Math.sqrt(3) / 3, y,
                x + 60 * Math.sqrt(3) / 3, y,
                x + 70 * Math.sqrt(3) / 3, y + 10,
                x + 60 * Math.sqrt(3) / 3, y + 20,
                x + 40 * Math.sqrt(3) / 3, y + 20,
                x + 30 * Math.sqrt(3) / 3, y + 30,
                x + 10 * Math.sqrt(3) / 3, y + 30,
                x, y + 20,
                x - 20 * Math.sqrt(3) / 3, y + 20,
                x - 30 * Math.sqrt(3) / 3, y + 10,
                x - 20 * Math.sqrt(3) / 3, y
        );
        polygon.setFill(Color.ORANGE);
        return polygon;
    }
}
